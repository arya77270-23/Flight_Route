import tkinter as tk
from tkinter import ttk, messagebox
import heapq
import folium
import webbrowser
import os
class FlightRoutePlanner:
    def __init__(self):
        self.graph = {}
        self.coordinates = {}

    def add_city(self, city, lat, lon):
        self.graph.setdefault(city, [])
        self.coordinates[city] = (lat, lon)

    def add_route(self, from_city, to_city, distance):
        if from_city in self.graph and to_city in self.graph:
            self.graph[from_city].append((to_city, distance))
            self.graph[to_city].append((from_city, distance))

    def find_shortest_route(self, start, destination):
        if start not in self.graph or destination not in self.graph:
            return None, None

        pq = [(0, start, [start])]
        visited = set()

        while pq:
            dist, city, path = heapq.heappop(pq)
            if city in visited:
                continue
            visited.add(city)

            if city == destination:
                return dist, path

            for neighbor, d in self.graph[city]:
                if neighbor not in visited:
                    heapq.heappush(pq, (dist + d, neighbor, path + [neighbor]))
        return None, None
class FlightPlannerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Flight Route Planner")
        self.geometry("950x700")
        self.config(bg="#E3F2FD")
        self.resizable(False, False)

        self.planner = FlightRoutePlanner()
        self.add_sample_data()

        self.show_welcome_page()
    def show_welcome_page(self):
        self.clear_window()

        bg_frame = tk.Frame(self, bg="#0D47A1")
        bg_frame.place(relwidth=1, relheight=1)

        title = tk.Label(
            bg_frame,
            text="Flight Route Planner",
            font=("Helvetica", 36, "bold"),
            fg="white",
            bg="#0D47A1"
        )
        title.pack(pady=100)

        subtitle = tk.Label(
            bg_frame,
            text="Plan your journey efficiently — find the shortest flight routes across India!",
            font=("Arial", 14, "italic"),
            fg="#E3F2FD",
            bg="#0D47A1"
        )
        subtitle.pack(pady=10)

        button_frame = tk.Frame(bg_frame, bg="#0D47A1")
        button_frame.pack(pady=100)

        start_btn = tk.Button(
            button_frame, text="Start Planning", font=("Arial", 16, "bold"),
            bg="#42A5F5", fg="white", width=18, height=2,
            relief="flat", activebackground="#1976D2",
            command=self.show_main_page
        )
        start_btn.grid(row=0, column=0, padx=20)

        quit_btn = tk.Button(
            button_frame, text="Quit", font=("Arial", 16, "bold"),
            bg="#E53935", fg="white", width=18, height=2,
            relief="flat", activebackground="#B71C1C",
            command=self.quit
        )
        quit_btn.grid(row=0, column=1, padx=20)
    def show_main_page(self):
        self.clear_window()
        tk.Label(
            self, text="Flight Route Planner ",
            font=("Helvetica", 22, "bold"), bg="#1565C0", fg="white", pady=10
        ).pack(fill="x")

        frame = tk.LabelFrame(self, text="Find Shortest Flight Route", bg="#E3F2FD", padx=10, pady=10)
        frame.pack(pady=30)

        tk.Label(frame, text="From City:", bg="#E3F2FD").grid(row=0, column=0, padx=5, pady=5)
        tk.Label(frame, text="To City:", bg="#E3F2FD").grid(row=0, column=2, padx=5, pady=5)

        self.combo_from = ttk.Combobox(frame, values=list(self.planner.coordinates.keys()), width=20, state="readonly")
        self.combo_to = ttk.Combobox(frame, values=list(self.planner.coordinates.keys()), width=20, state="readonly")

        self.combo_from.grid(row=0, column=1, padx=10)
        self.combo_to.grid(row=0, column=3, padx=10)

        tk.Button(
            frame, text="Find Route", bg="#1565C0", fg="white",
            font=("Arial", 12, "bold"), command=self.find_route
        ).grid(row=0, column=4, padx=10)

        self.result_label = tk.Label(frame, text="", bg="#E3F2FD", font=("Arial", 11, "bold"), fg="#1A237E")
        self.result_label.grid(row=1, column=0, columnspan=5, pady=10)
        self.tree = ttk.Treeview(self, columns=("From", "To", "Distance (km)"), show="headings", height=6)
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", width=200)
        self.tree.pack(pady=10)

        tk.Button(
            self, text="⬅ Back to Welcome", font=("Arial", 11, "bold"),
            bg="#90CAF9", command=self.show_welcome_page
        ).pack(pady=10)
    def find_route(self):
        from_city = self.combo_from.get()
        to_city = self.combo_to.get()

        if not from_city or not to_city:
            messagebox.showwarning("Missing Selection", "Please select both cities.")
            return

        total_distance, path = self.planner.find_shortest_route(from_city, to_city)

        if not path:
            self.result_label.config(text="No route found between selected cities.")
            return

        self.result_label.config(
            text=f"Shortest route found ({total_distance} km): {' → '.join(path)}"
        )
        self.tree.delete(*self.tree.get_children())
        for i in range(len(path) - 1):
            city1, city2 = path[i], path[i + 1]
            dist = next((d for c, d in self.planner.graph[city1] if c == city2), "—")
            self.tree.insert("", "end", values=(city1, city2, dist))
        self.plot_on_map(path)
    def plot_on_map(self, path):
        m = folium.Map(location=[22.5, 79], zoom_start=5, tiles="CartoDB positron")

        for city1, connections in self.planner.graph.items():
            lat1, lon1 = self.planner.coordinates[city1]
            for city2, dist in connections:
                lat2, lon2 = self.planner.coordinates[city2]
                if city1 < city2:
                    folium.PolyLine([(lat1, lon1), (lat2, lon2)],
                                    color="gray", weight=2, opacity=0.6,
                                    tooltip=f"{city1} ↔ {city2}: {dist} km").add_to(m)

        for i in range(len(path) - 1):
            lat1, lon1 = self.planner.coordinates[path[i]]
            lat2, lon2 = self.planner.coordinates[path[i + 1]]
            folium.PolyLine([(lat1, lon1), (lat2, lon2)],
                            color="red", weight=5, opacity=0.9,
                            tooltip=f"{path[i]} → {path[i+1]}").add_to(m)

        for city, (lat, lon) in self.planner.coordinates.items():
            folium.Marker(
                [lat, lon],
                popup=city,
                tooltip=city,
                icon=folium.Icon(color="blue" if city not in path else "red")
            ).add_to(m)

        map_path = "flight_routes_map.html"
        m.save(map_path)
        webbrowser.open(f"file://{os.path.abspath(map_path)}")
    def add_sample_data(self):
        cities ={
            "Delhi": (28.61, 77.23), "Mumbai": (19.07, 72.88), "Kolkata": (22.57, 88.36),
            "Chennai": (13.08, 80.27), "Bangalore": (12.97, 77.59), "Hyderabad": (17.38, 78.48),
            "Jaipur": (26.92, 75.82), "Ahmedabad": (23.03, 72.58), "Pune": (18.52, 73.86),
            "Amritsar": (31.63, 74.87), "Lucknow": (26.85, 80.95), "Guwahati": (26.14, 91.74),
            "Chandigarh": (30.74, 76.79), "Indore": (22.72, 75.86), "Patna": (25.61, 85.14),
            "Nagpur": (21.14, 79.08), "Visakhapatnam": (17.73, 83.3), "Kochi": (9.93, 76.26),
            "Bhubaneswar": (20.3, 85.82), "Varanasi": (25.32, 82.97)
        }
        for city, (lat, lon) in cities.items():
            self.planner.add_city(city, lat, lon)

        routes = [
            ("Delhi", "Jaipur", 280), ("Delhi", "Lucknow", 510), ("Delhi", "Amritsar", 450),
            ("Delhi", "Ahmedabad", 940), ("Delhi", "Mumbai", 1400), ("Delhi", "Kolkata", 1500),
            ("Delhi", "Hyderabad", 1250), ("Jaipur", "Ahmedabad", 650), ("Ahmedabad", "Mumbai", 520),
            ("Mumbai", "Pune", 150), ("Mumbai", "Hyderabad", 710), ("Mumbai", "Bangalore", 980),
            ("Hyderabad", "Chennai", 630), ("Bangalore", "Chennai", 290), ("Bangalore", "Kochi", 550),
            ("Kolkata", "Patna", 470), ("Patna", "Varanasi", 220), ("Patna", "Lucknow", 530),
            ("Kolkata", "Bhubaneswar", 440), ("Bhubaneswar", "Visakhapatnam", 390),
            ("Visakhapatnam", "Hyderabad", 620), ("Nagpur", "Hyderabad", 420), ("Indore", "Nagpur", 440),
            ("Indore", "Ahmedabad", 400), ("Lucknow", "Varanasi", 280), ("Amritsar", "Chandigarh", 220),
            ("Chandigarh", "Delhi", 250), ("Guwahati", "Kolkata", 980)
        ]
        for f, t, d in routes:
            self.planner.add_route(f, t, d)

    def clear_window(self):
        for widget in self.winfo_children():
            widget.destroy()
if __name__ == "__main__":
    app = FlightPlannerApp()
    app.mainloop()
